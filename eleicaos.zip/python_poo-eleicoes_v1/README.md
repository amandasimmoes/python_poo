# python_poo
Repositório de códigos de exemplos para a aula de Programação Orientada a Objetos

Esse repositório contém um exemplo inicial localizado no branch main, e nos demais branch serão colocados exemplos de um projeto a ser desenvolvido ao longo da disciplina.
